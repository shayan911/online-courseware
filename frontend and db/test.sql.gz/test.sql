-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2022 at 12:07 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `Course Code` int(100) NOT NULL,
  `Course Name` varchar(100) NOT NULL,
  `Instructor` varchar(100) NOT NULL,
  `No. of Chapters` int(30) NOT NULL,
  `Credit Hours` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`Course Code`, `Course Name`, `Instructor`, `No. of Chapters`, `Credit Hours`) VALUES
(10001, 'Maintaining Databases', 'Dr. Mohsen Hasan', 7, 32),
(20002, 'Fundamental of Physics', 'Erum', 5, 15),
(30004, 'Probability and Statistics ', 'Umer Iftikhar', 12, 25),
(50003, 'English for Journalism', 'Amber Light', 7, 18);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(320) NOT NULL,
  `phonenumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`firstname`, `lastname`, `username`, `password`, `email`, `phonenumber`) VALUES
('Alexander ', 'James', 'alejames', 'ale654', 'alj42@hkme.com', 485692),
('fsfa', 'afs', 'asf', 'asf', 'safffffff', 0),
('Ella', 'Jean', 'eljean', 'ellajean09', 'eljea43@hotmail.com', 756812),
('graeme', 'steve', 'gray', '202cb962ac59075b964b07152d234b70', 'gram@yahoo.com', 2147483647),
('John ', 'Watson', 'jwatson', 'joh123', 'jw98@gmail.com', 987456),
('Nazia', 'Hussain', 'nazhusa', 'naz753', 'nazhus79@gmail.com', 782651),
('Thomas', 'Carter', 'tcarter', 'tchar789', 'tcart31@yahoo.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `instructor`
--

CREATE TABLE `instructor` (
  `Instructor Id` int(11) NOT NULL,
  `Instructor Name` varchar(100) NOT NULL,
  `Qualification` varchar(100) NOT NULL,
  `Studied From` varchar(100) NOT NULL,
  `Teaching Experience` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor`
--

INSERT INTO `instructor` (`Instructor Id`, `Instructor Name`, `Qualification`, `Studied From`, `Teaching Experience`) VALUES
(1, 'Dr. Mohsen Hasan', 'Phd in Computer Sciences', 'University Of California', '7 Years'),
(2, 'Erum', 'Masters in Physics', 'Karachi University', '5 Years'),
(3, 'Umer Anjum', 'Certified Public Accountant (CPA)', 'LUMS', '6 Years'),
(4, 'Prof. Kidman', 'MSc in Applied Mathematics', 'Berkley University', '4 Years'),
(5, 'Amber Light', 'M.A in English', 'University of California', '8 Years');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`Course Code`),
  ADD UNIQUE KEY `Instructor` (`Instructor`),
  ADD KEY `Instructor_2` (`Instructor`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `User Name` (`username`);

--
-- Indexes for table `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`Instructor Id`),
  ADD KEY `Instructor Name` (`Instructor Name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
